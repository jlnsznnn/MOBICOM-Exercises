package com.mobdeve.dynamicviewcreation_template

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    // Complete the list of View variables here
    private lateinit var firstNameEtv: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize your View variables here using findViewById(R.id.<name of view in XML)
        this.firstNameEtv = findViewById(R.id.firstNameEtv)



        // Alternatively, you can use View Binding -- see the slides to enable View Binding

        // To add logic to the addBtn, add an onClickListener
        // Explore the auto-fill feature of Android Studio to find the appropriate method
        // After which:
        //  (1) Create a TextView object
        //  (2) Set the Text attribute of the object to the <Last>, <First> format
        //  (3) Add the newly created view to the LinearLayout
        this.addBtn




    }
}