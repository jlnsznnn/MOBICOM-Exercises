package com.mobdeve.tighee.emailapplication

class Email(val receiver: String, val subject: String, val body: String)