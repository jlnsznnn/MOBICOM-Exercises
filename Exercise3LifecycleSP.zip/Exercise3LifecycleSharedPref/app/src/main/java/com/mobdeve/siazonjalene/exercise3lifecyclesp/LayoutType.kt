package com.mobdeve.siazonjalene.exercise3lifecyclesp

enum class LayoutType {
    LINEAR_VIEW_TYPE, GRID_VIEW_TYPE
}